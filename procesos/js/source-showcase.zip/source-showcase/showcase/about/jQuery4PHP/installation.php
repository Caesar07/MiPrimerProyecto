You can
<a href="http://sourceforge.net/projects/jquery4php/files/">
  download
</a>
the library as a tar archive or a zip file. (comming soon .phar)
<br/><br/>
<h2><a class="title-link" >Installation via Subversion</a></h2>
The Subversion repository:
<a href="https://jquery4php.svn.sourceforge.net/svnroot/jquery4php ">
  http://sourceforge.net/projects/jquery4php/files/
</a>
<pre>
svn co https://jquery4php.svn.sourceforge.net/svnroot/jquery4php jquery4php
</pre>
<br/>
<h2><a class="title-link" >Installation via Git</a></h2>
The Git Browse:
<a href="http://jquery4php.git.sourceforge.net/git/gitweb-index.cgi">
  http://jquery4php.git.sourceforge.net/git/gitweb-index.cgi
</a>
<pre>
git clone git://jquery4php.git.sourceforge.net/gitroot/jquery4php/jquery4php
(read-only)
</pre>
<br/>
<h2><a class="title-link" >Installation via Pear</a></h2>
Unavailable.

