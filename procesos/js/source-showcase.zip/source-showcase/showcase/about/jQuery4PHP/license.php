<h2>
You may use the jQuery4PHP project under the terms of either the MIT License or the GNU General Public License (GPL) Version 2.</h2>
<br/><br/>
The MIT License is recommended for most projects. It is simple and easy to understand and it places almost no restrictions on what you can do with the jQuery4PHP project.
<br/><br/>
If the GPL suits your project better you are also free to use the jQuery4PHP project under that license.
<br/><br/>
You don’t have to do anything special to choose one license or the other and you don’t have to notify anyone which license you are using. You are free to use a jQuery4PHP project in commercial projects as long as the copyright header is left intact.
<ul>
<li>
<a href="https://jquery4php.svn.sourceforge.net/svnroot/jquery4php/trunk/MIT-LICENSE">MIT License</a>
(
<a href="http://en.wikipedia.org/wiki/MIT_License">More Information</a>
)
</li>
<li>
<a href="https://jquery4php.svn.sourceforge.net/svnroot/jquery4php/trunk/GPL-LICENSE">GPL</a>
(
<a href="http://en.wikipedia.org/wiki/GNU_General_Public_License">More Information</a>
)
</li>
</ul>
