<pre>
  YsJQuery::clearQueue()
    ->queueName('queueName') // <- The queueName is optional
</pre>
