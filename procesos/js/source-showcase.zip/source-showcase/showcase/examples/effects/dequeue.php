<pre>
  YsJQuery::dequeue()->queueName('queueName');
</pre>
