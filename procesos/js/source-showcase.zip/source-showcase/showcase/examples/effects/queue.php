<pre>
  YsJQuery::queue()
</pre>