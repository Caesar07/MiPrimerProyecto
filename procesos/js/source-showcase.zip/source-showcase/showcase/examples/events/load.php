<pre>
  YsJQuery::newInstance()
    ->onLoad()
    ->in('window')
    ->execute(
      "alert('Window loaded')"
    )
</pre>