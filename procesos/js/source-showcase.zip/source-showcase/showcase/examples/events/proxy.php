<pre>
  YsJQuery::newInstance()
    ->execute(
      YsJQuery::proxy()
        ->context('obj')
        ->name("test")
    )
</pre>