<pre>
YsJQuery::detach('#the-selector')
</pre>