<pre>
echo YsJQuery::innerHeight()->in('#the-selector')
</pre>