<pre>
echo YsJQuery::innerWidth()->in('#the-selector')
</pre>