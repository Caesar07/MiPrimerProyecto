<pre>
  echo YsJQuery::outerHeight()->in('#the-selector')
</pre>