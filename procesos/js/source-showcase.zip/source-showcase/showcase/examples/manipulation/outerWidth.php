<pre>
  echo YsJQuery::outerWidth()->in('#the-selector')
</pre>