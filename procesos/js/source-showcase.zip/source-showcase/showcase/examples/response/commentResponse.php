Thanks for your comment:<br/>
<b>Name:</b> <?php echo $_POST['name']?><br/>
<b>E-mail:</b> <?php echo $_POST['email']?><br/>
<b>URL:</b> <?php echo $_POST['url']?><br/><br/>
<b>Comment:</b><br/>
<hr/>
<div>
  <?php echo $_POST['comment']?>
</div>


