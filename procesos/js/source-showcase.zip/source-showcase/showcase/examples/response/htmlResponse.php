<table border="1">
  <tr>
    <td style="background-color:#00CCFF; color:white"> Hello
    </td>
    <td style="background-color:#00CCFF; color:white"> World
    </td>
  </tr>
</table>