<?php 
Header('Content-Type: application/json;');
echo '{"BARN":"Barnstable","PLYM":"Plymouth"}'
?>