<?php
echo date('l jS \of F Y') . date('h:i:') . (int) date('s') + 1 . date('A');

?>